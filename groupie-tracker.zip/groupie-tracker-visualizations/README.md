#### About 
###### [Here](https://github.com/01-edu/public/tree/master/subjects/groupie-tracker/visualizations) you can read about the project.

#### How to run?

###### You can call comand "make pusk" in terminal to run main.go file
###### or call comand "make pusk-docker" in terminal to build Docker image and run container.